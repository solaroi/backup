import os, requests, base64

#update user-rule.txt, the gfwlist rule used to update pac rule: pac.txt
url = 'https://raw.githubusercontent.com/gfwlist/gfwlist/master/gfwlist.txt'
response = requests.get(url)
with open('../user-rule.txt', 'ab') as f:
    f.write(base64.b64decode(response.content))


#update user.rule, the inside proxy rule
userRule = open('user.rule', 'w', encoding='utf-8')
userRule.write('##no remoteporxy configured, use gfwlist in pac instead\n##localproxy china domains\n##if no domain matched, localproxy china ips\n')
userRule.write('\n##china domain\n')
url = 'https://raw.githubusercontent.com/felixonmars/dnsmasq-china-list/master/accelerated-domains.china.conf'
chinaDomainList = url.split('/')[-1]
response = requests.get(url)
# with open(chinaDomainList,'wb') as f:
    # f.write(response.content)
f1 = open(chinaDomainList, 'r', encoding='utf-8')
userRule.write('.cn localproxy\n')
lines = f1.readlines()
for line in lines:
		userRule.write('.' + line.split('/')[1] + ' localproxy\n')
f1.close()
userRule.write('\n##china ip\n')
allProxy = ''':: ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff remoteproxy
0.0.0.0 255.255.255.255 remoteproxy
'''
lanIPs = '''10.0.0.0 10.255.255.255 direct
172.16.0.0 172.31.255.255 direct
192.168.0.0 192.168.255.255 direct
169.254.0.0 169.254.255.255 direct
127.0.0.0 127.255.255.255 direct
'''
userRule.write(allProxy + lanIPs)
f1 = open('..\chn_ip.txt', 'r', encoding='utf-8')
lines = f1.readlines()
for line in lines:
    userRule.write(line[:-2] + ' localproxy\n')
f1.close()   

# optional: use china ip list maintained by https://www.ip2location.com/free/visitor-blocker
# url = 'https://raw.githubusercontent.com/17mon/china_ip_list/master/china_ip_list.txt'
# chinaIPList =  url.split('/')[-1]
# response = requests.get(url)
# with open(chinaIPList,'wb') as f:
    # f.write(response.content)
# f1 = open(chinaIPList, 'r', encoding='utf-8')
# lines = f1.readlines()
# ipStrsStart = ['']*4
# ipStrsEnd = ['']*4
# for line in lines:
    # [ipStr, num] = line.split('/')
    # num = int(num)
    # if num>=32:
       # userRule.write('.'.join(ipStrs) + ' ' + '.'.join(ipStrs) + ' localproxy\n')
       # continue
    # ipStrs = ipStr.split('.')
    # net = int(ipStrs[num//8]) & (256-2**(8-num%8))
    # ipStrs[num//8] = str(net)
    # for i in range(num//8+1, 4):
        # ipStrs[i]='0'
    # userRule.write('.'.join(ipStrs)+' ')
    # ipStrs[num//8] = str(net + 2**(8-num%8) - 1)
    # for i in range(num//8+1, 4):
        # ipStrs[i]='255'
    # userRule.write('.'.join(ipStrs)+' localproxy\n')
# f1.close()
